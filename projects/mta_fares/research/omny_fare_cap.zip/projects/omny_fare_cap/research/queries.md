# Exact API calls

Every query below was run on 2026-09-28 and returned the recorded result. Copy-pasteable.
Note the domain split: ridership is `data.ny.gov`, Fair Fares is `data.cityofnewyork.us`.

## Verified

### Fare-class composition, 2026 window (`5wq4-mkjj`)

```
https://data.ny.gov/resource/5wq4-mkjj.json?$select=fare_class_category,sum(ridership)&$where=transit_timestamp>'2026-09-01'&$group=fare_class_category
```

Returned 10 categories. See `tests/fixtures/fare_class_2026.json`.

**Caution:** this is the exact query that caused the scoping error. With no upper
bound it covers 2026-09-01 .. 2026-09-16 (the dataset's coverage end), not two days.
The pipeline uses an explicit half-open window instead.

### Fare-class composition, 2024 window (`wujg-7c2s`)

```
https://data.ny.gov/resource/wujg-7c2s.json?$select=fare_class_category,sum(ridership)&$where=transit_timestamp>'2024-09-01' AND transit_timestamp<'2024-09-17'&$group=fare_class_category
```

Returned 12 categories, including both `Metrocard - Unlimited 30-Day` (3,979,572) and
`Metrocard - Unlimited 7-Day` (4,178,161). See `tests/fixtures/fare_class_2024.json`.

### Window reconciliation, 2026

```
https://data.ny.gov/resource/5wq4-mkjj.json?$select=count(*),sum(ridership),min(transit_timestamp),max(transit_timestamp)&$where=transit_timestamp>'2026-09-01'
```

```json
[{"count":"807594","sum_ridership":"58876993.0",
  "min_transit_timestamp":"2026-09-01T01:00:00.000",
  "max_transit_timestamp":"2026-09-16T23:00:00.000"}]
```

807,594 rows / 16 days ≈ 3.68M rides per day, which is the sanity check that the
window is right.

### Dataset metadata, `5wq4-mkjj`

```
https://data.ny.gov/api/views/5wq4-mkjj.json
```

45,243,727 rows; `rowsUpdatedAt` 1790174781 = 2026-09-23 14:46:21 UTC.

### Column confirmation

```
https://data.ny.gov/resource/5wq4-mkjj.json?$limit=2
```

Keys: `transit_timestamp`, `transit_mode`, `station_complex_id`, `station_complex`,
`borough`, `payment_method`, `fare_class_category`, `ridership`, `transfers`,
`latitude`, `longitude`, `georeference`.

### Fair Fares enrollment (`3tw8-6si8`, city domain)

```
https://data.cityofnewyork.us/resource/3tw8-6si8.json?$limit=5&$order=month DESC
https://data.cityofnewyork.us/resource/3tw8-6si8.json?$select=count(*),min(month),max(month)
```

92 monthly rows, 2019-01-01 .. 2026-08-01. Columns: `month`,
`total_fair_fares_enrollees`. August 2026: 382,820.

## Written but never run

### Station x fare class — the load-bearing pull

```
https://data.ny.gov/resource/wujg-7c2s.json?$select=station_complex_id,station_complex,borough,fare_class_category,sum(ridership)&$where=transit_timestamp>'2024-09-01' AND transit_timestamp<'2024-09-17'&$group=station_complex_id,station_complex,borough,fare_class_category&$limit=50000
```

Implemented as `farecap.collect.station_fare_class(2024)`. Run this first.

### 2024 window reconciliation — still open

```
https://data.ny.gov/resource/wujg-7c2s.json?$select=count(*),sum(ridership),min(transit_timestamp),max(transit_timestamp)&$where=transit_timestamp>'2024-09-01' AND transit_timestamp<'2024-09-17'
```

Expected to return 53,599,970 if the fare-class split is complete. Never run.

## Queries that failed, and why

- Unbounded `$select=fare_class_category,payment_method,sum(ridership)&$group=...` over
  `5wq4-mkjj`: **read timeout.** 45.2M rows. Always bound the window.
- `$select=transit_timestamp&$order=transit_timestamp DESC&$limit=1` returned
  `2026-09-02T23:00:00.000`, contradicting the bounded aggregate's 2026-09-16. Trust
  the bounded aggregate.
- A long query URL with a fully-qualified two-sided timestamp filter plus `$group` and
  `$order` was rejected by an HTTP intermediary for length before reaching Socrata.
  Keep clauses terse.
