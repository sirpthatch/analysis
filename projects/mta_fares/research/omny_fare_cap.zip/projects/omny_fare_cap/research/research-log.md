# Research log

## 2026-09-28 — scoping session

Origin: this came out of a daily news-scan brief. It was initially **cut** from that
brief on the grounds that the data lives on `data.ny.gov` rather than NYC Open Data,
then reopened. Two corrections came out of reopening it, both worth recording because
they are the kind of mistake that recurs:

1. The domain objection was wrong in substance. `data.ny.gov` is the same Socrata API
   with the same verifiability. The real constraint is that the *city* data available
   (Fair Fares, `3tw8-6si8`) is thin — two columns, no geography.
2. The story was initially filed as "fare restructuring," which is too vague to
   analyse. Reading the 2026-09-23 Streetsblog piece showed it is specifically about
   **fare capping** — no distance-based, zone or free-bus proposals are in play. Fare
   capping is arithmetic, which is what made the project tractable.

### The premise, established

Verified from the MTA's own January 2026 board adoption: the 7-Day, 30-Day and Express
Bus Plus unlimited MetroCards were retired and "replaced with the automatic fare cap."
The cap is weekly only. So the 7-day product has a successor and the 30-day product
does not. Everything else in the project follows from that asymmetry.

### Composition finding

Two sixteen-day windows, same calendar position, two years apart. Full figures in
`constants.RECORDED_FARE_CLASS_RIDERSHIP`, fixtures in `tests/fixtures/`.

- Sept 1–16 2024: 53,599,970 rides. MetroCard 38.19%. Unlimited passes 15.22% of all
  rides — 30-Day 3,979,572 (7.42%), 7-Day 4,178,161 (7.80%).
- Sept 1–16 2026: 58,876,993 rides (+9.8%). MetroCard **0.451%**. 30-Day Unlimited: 31
  rides. 7-Day Unlimited: category absent from the schema.

So roughly one subway ride in thirteen used to be taken on a monthly pass, and the
product no longer exists at any price.

### Process error worth keeping

The 2026 fare-class query was first run as `$where=transit_timestamp>'2026-09-01'` with
no upper bound. I read the result as covering two days and got ~58.9M rides, which is
absurd — about 29M/day against an actual system figure near 3.7M. Running the
independent `count(*),sum(ridership),min,max` aggregate revealed the window was
actually 2026-09-01 .. 2026-09-16, sixteen days, at 3.68M/day, which is correct.

Two consequences, both now baked into the code: every window in `farecap.collect` is
explicit and half-open, and `fareclass.composition` reconciles the fare-class split
against an independent total and refuses to report an unreconciled split as reconciled.
The 2024 side of that reconciliation was never run — open item 2.

### Cap arithmetic

$35/week × 52 ÷ 12 = $151.67/month for a rider who caps every week. ETA's proposed
46 rides × $3.00 = $138.00. Gap $13.67/month, $164/year.

Deliberately **not** computed: the change against the retired pass's price. The $132
figure in circulation is arithmetically plausible (132 ÷ 2.90 = 45.5 rides) but was not
found in any MTA fare schedule or board document. Open item 3. `cap_arithmetic()`
carries the caveat in its return value so it cannot be quoted without it.

### Method decision: revealed preference

The direct question — how many riders would hit a 46-ride monthly cap — is
**unanswerable** with these datasets. They are aggregated by station, hour and fare
class; there is no rider identifier and no trip chain. Recorded in limitations.md as
fatal to that framing.

The substitute: riders who bought a 30-Day Unlimited had already declared themselves
high-frequency, so the 2024 data grouped by station gives the share of each station's
ridership taken on a monthly pass — a map of where the affected riders board, with no
per-rider model. Implemented in `farecap.stations`, **never run**.

The kill condition is explicit in `stations.dispersion_verdict`: if the interquartile
range of station-level monthly-pass share is under 2 percentage points, the
distribution is flat, there is no geography, and the equity framing collapses. That
verdict should be published either way.

### Fair Fares aside

`3tw8-6si8`: 92 monthly rows, Jan 2019 – Aug 2026. Enrollment 381,558 (Apr) → 383,377
(May) → 384,914 (Jun) → 384,372 (Jul) → 382,820 (Aug). Flat, slightly down from June,
eight months after the fare increase. Mildly interesting; no geography, so analytically
thin. Not load-bearing.

### Environment note

The scoping environment had no direct HTTP egress from Python — the proxy refused
`requests` calls to `data.ny.gov` with a 403 tunnel failure. All figures above were
verified through a separate fetch path and committed as fixtures. The pipeline runs
end-to-end offline against those fixtures (`python src/seed_cache.py && python
src/analyze.py --composition --arithmetic` reproduces every number in this log) but has
**never contacted the live APIs**. First live run is a verification step.

One genuine bug was caught by the test suite during scoping: `cap_arithmetic` rounds
`rides_to_hit_weekly_cap` to 11.67 for display, and the test compared it against
35/3.00 at 1e-6 relative tolerance. Fixed in the test, not the rounding.
