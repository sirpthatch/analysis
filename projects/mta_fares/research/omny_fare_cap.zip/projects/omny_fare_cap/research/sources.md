# Sources

## Primary documents

- **MTA board adoption of January 2026 fares and tolls.**
  https://www.mta.info/press-release/mta-board-adopts-fare-and-toll-increases-take-effect-january-2026
  Base $2.90→$3.00, reduced $1.45→$1.50, express bus $7.00→$7.25, weekly cap $35 /
  $17.50 reduced. States the 7-Day, 30-Day and Express Bus Plus unlimited passes
  "retire and be replaced with the automatic fare cap for all riders." **This is the
  load-bearing citation for the whole piece.** Fetched 2026-09-28.

- **Wikipedia, New York City transit fares.**
  https://en.wikipedia.org/wiki/New_York_City_transit_fares
  Corroborates that as of January 2026 the 7-day cap is the only unlimited option and
  30-day options were discontinued except on AirTrain JFK. Does **not** give the retired
  passes' prices. Secondary — use for orientation, cite the MTA document.

## News hooks

- **Streetsblog NYC, 2026-09-23 — "MTA Chair Open To New Fare Structure Ahead Of 2027
  Fare Hike"** (Dave Colon).
  https://nyc.streetsblog.org/2026/09/23/mta-chair-open-to-new-fare-structure-ahead-of-2027-fare-hike
  Janno Lieber open to caps beyond the weekly one, "different ways to use the
  technology," wants an "equity oriented fare structure." PCAC's Lisa Daglian: "A
  30-day fare cap is something we've heard a lot about." Also: LIRR family fare usage
  +38% after the age limit went 12→17. No distance-based, zone or free-bus proposals in
  the piece — the story is fare capping specifically.

- **Streetsblog NYC, 2026-02-18 — "Advocates to MTA: More Fare Caps Will Be Fairer For
  All."**
  https://nyc.streetsblog.org/2026/02/18/advocates-to-mta-more-fare-caps-will-be-fairer-for-all
  Effective Transit Alliance's Blair Lorenzo: "A cap of 46 rides over 30 days would at
  least restore the status quo," and "The end of the monthly MetroCard actually meant a
  massive fare hike for New York's most loyal riders." PCAC's Brian Fritsch on more
  caps. Cites monthly caps raising ridership ~4% on US systems, and LA / London /
  Milwaukee offering multiple cap tiers. **Contains no quantification of how many riders
  would benefit — that absence is the gap this project fills.**

## Prior art — what is already published

The *argument* that losing the monthly pass was a stealth fare hike is on the record
from ETA and PCAC, and Streetsblog has covered it at least twice (Feb and Sept 2026).
What has not been published: the share of ridership that was on monthly passes, where
those riders board, and the per-month cost of the change. No denominator anywhere in
the coverage.

## Not checked

- MTA board minutes / archived fare schedules for the retired passes' prices. **Open
  item 3.**
- Any MTA methodology note on the `wujg-7c2s` → `5wq4-mkjj` seam at 2025-01-01.
- The MTA data dictionaries for both ridership datasets (needed for the "Other"
  buckets).
