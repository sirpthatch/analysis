# Handoff

Nothing here yet. This directory exists for the same reason it does in
`afforable_housing_fasttrack`: to preserve ad-hoc pulls from prior sessions once
the pipeline supersedes them.

The scoping session's pulls are in `tests/fixtures/` instead, because they double as
test fixtures and as the offline cache seed. See `tests/fixtures/README.md` for what
was captured and what was deliberately not.
