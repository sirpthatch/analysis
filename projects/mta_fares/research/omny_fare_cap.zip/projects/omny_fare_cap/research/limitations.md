# Limitations and open questions

Running list of what the data cannot support. Update as things are resolved or found.

## Fatal to the obvious approach

**There is no rider identifier anywhere in these datasets.** Ridership is aggregated by
station, hour and fare class. So you **cannot** compute how many riders would reach a
46-ride monthly cap, how many currently hit the weekly cap, or any per-rider trip
distribution. Any analysis framed as "N riders would benefit" is unsound with these
sources. The revealed-preference workaround — 30-day-pass ridership by station, since
buying the pass *was* the declaration of high frequency — is the only defensible route,
and it measures where affected riders board, not how many there are.

## Numerator / category problems

**The "Other" buckets are unexplained.** `Metrocard - Other` was 1,917,214 rides in the
2024 window; `OMNY - Other` is 2,343,404 in the 2026 window. Nobody has read the MTA
data dictionary to establish what is in them. If pass products are pooled into "Other,"
the headline 7.42% monthly-pass share is either a floor or contaminated. **This is the
most likely way the central number is wrong.** Resolve before publishing.

**The student series moves too much to ignore.** OMNY Students 2,343,858 → 1,570,400
across the two windows, a 33% drop, against 9.8% total ridership growth. Almost
certainly a category or school-calendar artifact rather than behavior. Until explained
it undercuts any claim about *total* composition, though it does not touch the
monthly-pass figure directly.

**Category absence vs zero.** `Metrocard - Unlimited 7-Day` is absent from the 2026
schema entirely, not reported as zero; `Metrocard - Students` is absent from 2026 and
present as 2 rides in 2024. Code that groups across both windows must preserve the
distinction. `fareclass.comparison` keeps NaN rather than filling zero for this reason.

## Reconciliation and seams

**The 2024 window total is unreconciled.** The fare-class split sums to 53,599,970 but
no independent `count(*),sum(ridership)` was ever run for that window. The equivalent
check on 2026 is what caught a silent window-length error, so this gap is real.
`python src/collect.py windows --refresh` closes it.

**The two windows come from two different datasets** (`wujg-7c2s` and `5wq4-mkjj`) with
a seam at the start of 2025. Any schema change, estimation-method change or
reprocessing at that boundary will present as a two-year trend. No MTA methodology-
continuity note has been located.

**These are estimates.** The MTA describes both datasets as providing ridership
*estimates*, not counts. Treat precision accordingly; do not report figures to more
significant digits than an estimate supports.

**Ridership vs transfers.** `ridership` and `transfers` are separate columns. Shares
differ depending on the denominator chosen. Pick one and state it in the piece.

**Station complexes get renamed and merged.** A 2024→2026 join on `station_complex`
silently drops rows. `stations.join_across_windows` joins on `station_complex_id` and
reports the unmatched counts on both sides; check them before trusting any change
figure.

## Unverified facts

**The retired 30-Day Unlimited price.** Widely repeated as $132, arithmetically
consistent with a $2.90 base fare (45.5-ride breakeven), but not found in any MTA fare
schedule or board document during scoping. Held in
`constants.METROCARD_30DAY_FINAL_PRICE_UNVERIFIED` and deliberately unused by
`cap_arithmetic`. **No before/after dollar figure may be published until this is
sourced from a primary document.**

**`wujg-7c2s` coverage end** is assumed from the dataset title (2024-12-31), not
verified by query.

**`5zyy-y8am`-style metadata drift.** For `5wq4-mkjj`, the catalog index and the
metadata endpoint have disagreed on update dates elsewhere in this repo's projects.
The `rowsUpdatedAt` of 2026-09-23 came from the metadata endpoint and is the one to
trust, but re-check.

## Scope limitations

**Fair Fares gives no geography.** `3tw8-6si8` is two columns of citywide monthly
totals. It cannot support any neighborhood or income-level claim. It is the only NYC
Open Data source in the project, which is worth knowing if the piece is framed as a
city-data story.

**Bus is out of scope for now.** The fare cap covers local bus, and `gxb3-akrn` /
`kv7t-n8in` share the subway schema, but their columns are unverified and the bus
analysis is only worth doing if the subway geography holds up.

**The pipeline has never touched the live APIs.** Written and tested against committed
fixtures only. Treat the first live run as a verification step, not a formality.
