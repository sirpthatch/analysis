# OMNY Fare Cap — what replaced the 30-Day Unlimited MetroCard

Quantifying the rider population affected when the MTA retired the monthly
unlimited pass in January 2026 and replaced it with a weekly-only fare cap.

Read `CLAUDE.md` first for the story, the state of play, and the open items.

## Status

Scoped 2026-09-28. The pipeline is written and runs end-to-end against committed
fixtures. **It has not been run against the live APIs** — the scoping environment had
no direct HTTP egress, so the figures were verified through a separate fetch path and
recorded in `tests/fixtures/`. The station-level analysis, which is the load-bearing
question, has never executed.

## Layout

```
CLAUDE.md                  handoff brief — story, facts, open items, gotchas
README.md                  this file
requirements.txt
src/
  collect.py               CLI: cache the aggregate pulls
  analyze.py               CLI: composition, cap arithmetic, station tables
  seed_cache.py            CLI: copy fixtures into data/raw/ for offline work
  farecap/
    constants.py           verified dataset ids, fare schedule, recorded figures
    collect.py             Socrata access — server-side aggregates only
    fareclass.py           fare-class composition, shares, cap arithmetic
    stations.py            per-station monthly-pass share + flatness verdict
research/
  research-log.md          sourced detail, every claim with its provenance
  queries.md               exact API calls, copy-pasteable
  plan.md                  phased plan
  limitations.md           what the data cannot support
  sources.md              news and document sources with dates
tests/
  test_verified_figures.py re-checks recorded figures against the live APIs
  fixtures/                verbatim responses from the scoping session
notebooks/
article/
  outline.md               draft structure
data/raw/                  gitignored; rebuild with src/collect.py
output/                    gitignored; CSVs from src/analyze.py
```

## Setup

```bash
pip install -r requirements.txt
```

## Running it

Offline, against the committed fixtures — works with no network:

```bash
python src/seed_cache.py
python src/analyze.py --composition --arithmetic
```

That reproduces the headline composition table, the shares, and the cap arithmetic.

On a networked machine, do this first:

```bash
export SOCRATA_APP_TOKEN=...        # optional, raises the rate limit
python src/collect.py all --refresh # re-query everything
pytest tests/                       # confirm the recorded figures still hold
python src/analyze.py --all         # adds the station-level analysis
```

`pytest` hitting the network is deliberate: the tests are the re-verification step, not
a unit-test suite. A failure most likely means the MTA restated its ridership
estimates, which belongs in `research/research-log.md`.

## The one query that decides the project

```bash
python src/analyze.py --stations
```

It prints a verdict: `DISPERSED` means 30-day-pass share varies by station and the map
is worth building; `FLAT` means it doesn't, there is no geography, and the piece is a
citywide arithmetic note. Run it before investing in anything else.

## Data sources

| Dataset | Id | Domain |
|---|---|---|
| MTA Subway Hourly Ridership: Beginning 2025 | `5wq4-mkjj` | data.ny.gov |
| MTA Subway Hourly Ridership: 2020-2024 | `wujg-7c2s` | data.ny.gov |
| Fair Fares Enrollees (HRA) | `3tw8-6si8` | data.cityofnewyork.us |

Further ids, unverified, in `constants.DATASETS`.
