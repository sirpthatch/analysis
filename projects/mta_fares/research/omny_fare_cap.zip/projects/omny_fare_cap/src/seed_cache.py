#!/usr/bin/env python3
"""Copy the committed 2026-09-28 fixtures into data/raw/ so the analysis runs offline.

    python src/seed_cache.py

Seeded pulls are then used by collect.py's cache. Pass --refresh to any
collect/analyze command to overwrite them with live data.
"""

import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "tests" / "fixtures"
DEST = ROOT / "data" / "raw"


def main() -> int:
    DEST.mkdir(parents=True, exist_ok=True)
    seeded = []
    for src in sorted(FIXTURES.glob("*.json")):
        shutil.copy2(src, DEST / src.name)
        seeded.append(src.name)
    if not seeded:
        print("no fixtures found", file=sys.stderr)
        return 1
    for name in seeded:
        print(f"seeded {name}")
    print(f"\n{len(seeded)} fixtures -> {DEST}")
    print("NOTE: window_total_2024 and station_fare_class_* are absent by design.")
    print("Run `python src/collect.py all --refresh` on a machine with network access.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
