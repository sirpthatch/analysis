#!/usr/bin/env python3
"""Produce the analysis tables.

    python src/analyze.py --all
    python src/analyze.py --composition   # fare-class split, both windows
    python src/analyze.py --arithmetic    # weekly cap vs a restored monthly cap
    python src/analyze.py --stations      # per-station monthly-pass share + verdict

Writes CSVs to output/ and prints the figures worth reading aloud.
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import pandas as pd  # noqa: E402

from farecap import constants as C, fareclass, stations  # noqa: E402

OUT = Path(__file__).resolve().parents[1] / "output"


def _write(df: pd.DataFrame, name: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / name
    df.to_csv(path, index=True)
    print(f"  -> {path.relative_to(OUT.parent)}")


def do_composition(refresh: bool) -> None:
    print("\n=== Fare-class composition, 16-day windows two years apart ===")
    wide = fareclass.comparison(refresh=refresh)
    with pd.option_context("display.width", 140, "display.max_columns", 20):
        print(wide.to_string())
    _write(wide, "fare_class_comparison.csv")

    print("\n--- reconciliation ---")
    for year in sorted(C.WINDOWS):
        df = fareclass.composition(year, refresh=refresh)
        rec = df.attrs["reconciles"]
        if rec is None:
            print(f"  {year}: fare-class sum {df.attrs['fare_class_sum']:,.0f} vs "
                  f"window total UNAVAILABLE [NOT RECONCILED]")
            print(f"        reason: {df.attrs['reconcile_error']}")
        else:
            span = df.attrs["observed_span"]
            print(f"  {year}: fare-class sum {df.attrs['fare_class_sum']:,.0f} vs "
                  f"window total {df.attrs['window_total']:,.0f} "
                  f"[{'OK' if rec else 'MISMATCH'}]")
            print(f"        observed span {span[0]} .. {span[1]}")

    print("\n--- headline shares ---")
    for k, v in fareclass.headline_shares(refresh=refresh).items():
        print(f"  {k:34s} {v:,}")


def do_arithmetic() -> None:
    print("\n=== Cap arithmetic ===")
    for k, v in fareclass.cap_arithmetic().items():
        if k == "caveat":
            print(f"\n  CAVEAT: {v}")
        else:
            print(f"  {k:36s} {v}")


def do_stations(refresh: bool) -> None:
    print("\n=== Station-level monthly-pass concentration (2024 window) ===")
    verdict = stations.dispersion_verdict(2024, refresh=refresh)
    for k, v in verdict.items():
        print(f"  {k:30s} {v}")

    tbl = stations.station_table(2024, refresh=refresh)
    ranked = tbl[~tbl["below_volume_floor"]]
    print("\n--- top 15 by monthly-pass share ---")
    print(ranked.head(15)[["station_complex", "borough", "total_ridership",
                           "monthly_pass_share_pct"]].to_string(index=False))
    print("\n--- bottom 10 by monthly-pass share ---")
    print(ranked.tail(10)[["station_complex", "borough", "total_ridership",
                           "monthly_pass_share_pct"]].to_string(index=False))
    _write(tbl, "station_monthly_pass_share_2024.csv")

    print("\n--- borough rollup ---")
    print(stations.borough_rollup(2024, refresh=refresh).to_string(index=False))


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--all", action="store_true")
    p.add_argument("--composition", action="store_true")
    p.add_argument("--arithmetic", action="store_true")
    p.add_argument("--stations", action="store_true")
    p.add_argument("--refresh", action="store_true", help="ignore cache, re-query")
    args = p.parse_args()

    if not any([args.all, args.composition, args.arithmetic, args.stations]):
        p.print_help()
        return 2

    if args.all or args.composition:
        do_composition(args.refresh)
    if args.all or args.arithmetic:
        do_arithmetic()
    if args.all or args.stations:
        do_stations(args.refresh)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
