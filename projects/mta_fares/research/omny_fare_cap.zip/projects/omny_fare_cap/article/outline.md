# Draft outline

Working title: **The MTA retired the monthly pass and replaced it with nothing**

Do not write this until `python src/analyze.py --stations` has run. The outline
branches on its verdict.

## Lead

Not the arithmetic. The lead is the retirement: in January 2026 the MTA raised the base
fare to $3.00 and, in the same board action, retired the 7-Day, 30-Day and Express Bus
Plus unlimited MetroCards, saying they would "be replaced with the automatic fare cap
for all riders." The cap is weekly. The 7-day pass got a successor. The 30-day pass
didn't.

## The size of the affected population

One ride in thirteen — 7.4% of subway ridership in a sixteen-day September 2024 window —
was taken on a 30-Day Unlimited. Today that product shows 31 rides in the equivalent
window and the 7-Day category is gone from the data entirely. Table: the two windows
side by side.

## What it costs

$35/week × 52 ÷ 12 = $151.67 a month for a rider who caps every week. ETA's proposed
46-ride cap would be $138. The gap is $13.67 a month, $164 a year, on the riders who
ride most.

Hold the before/after comparison against the retired pass price until it's sourced.
If it can't be sourced, the ETA comparison carries the section on its own.

## Where those riders are — BRANCH

**If DISPERSED:** the map. Which station complexes had the highest monthly-pass share in
2024, what they have in common, and which council or community districts they sit in.
This is the equity section, and it's the version Lieber's "equity oriented fare
structure" quote hangs on.

**If FLAT:** say so plainly, in a short section. The monthly pass was used
proportionately across the system, so this was a uniform increase on frequent riders
rather than a geographically concentrated one. That is a real finding and it makes the
piece shorter, not weaker. Cut the map, keep the arithmetic, close on the policy.

## The policy moment

Lieber, 2026-09-23: open to caps beyond the weekly one, wants an "equity oriented fare
structure," with a fare increase planned for 2027. Advocates have been asking since
February. The number this piece supplies is the one missing from that conversation.

## What I can't tell you

Be explicit, in the piece: this data cannot say how many riders would hit a 46-ride
cap, because it has no rider identifier. What it can say is how much ridership rode on
the monthly product and where. Note the "Other" bucket ambiguity if it survives
open item 4.
