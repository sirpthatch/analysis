# OMNY Fare Cap: the monthly pass the MTA retired and never replaced

Project brief for continuing this analysis. Read this file first, then
`research/research-log.md` for sourced detail and `research/queries.md` for exact API
calls. `README.md` describes the project layout and how to run the pipeline.

The project was scoped on 2026-09-28 from a news-scan session; the pipeline in `src/`
was written the same day but **has never been run against the live APIs** — the scoping
environment had no direct HTTP egress, so every figure below was verified through a
separate fetch path and committed as fixtures in `tests/fixtures/`. See
`research/limitations.md` for the running list of what the data cannot support and
`research/plan.md` for the phased plan. First thing on a networked machine:
`python src/collect.py all --refresh && pytest tests/`.

## The story

In January 2026 the MTA raised the base fare from $2.90 to $3.00 and, in the same
board action, retired the 7-Day, 30-Day and Express Bus Plus unlimited MetroCards —
in its own words, they "retire and be replaced with the automatic fare cap for all
riders." But the replacement cap is **weekly only**: $35 a week, $17.50 reduced. The
7-day pass got a successor. The 30-day pass did not.

The angle: quantify the population that absorbed that change. In a sixteen-day window
in September 2024, 7.4% of all subway rides were taken on a 30-Day Unlimited — roughly
one ride in thirteen. Two years later the same window shows 31 rides on that product
and the 7-Day Unlimited category has vanished from the schema entirely. Advocates
(Effective Transit Alliance, PCAC) have been making the argument since February 2026
that this was a stealth fare hike on the city's most frequent riders; ETA proposes a
46-ride/30-day cap to "restore the status quo." Nobody has published the denominator.

On 2026-09-23 MTA chair Janno Lieber said he is open to caps beyond the weekly one and
wants an "equity oriented fare structure," ahead of a planned 2027 fare increase. That
is the hook: there is now a decision-maker to hold a number up against.

## The facts, precisely

- **Fare schedule (effective January 2026):** base $2.90 → $3.00; reduced $1.45 →
  $1.50; express bus $7.00 → $7.25. Weekly cap $35, reduced weekly cap $17.50.
- **Retired:** MetroCard 7-Day, 30-Day and Express Bus Plus unlimited passes.
- **Cap arithmetic:** $35/week × 52 ÷ 12 = **$151.67/month** for a rider who caps every
  week. ETA's proposal is 46 × $3.00 = **$138.00/month**. Gap: **$13.67/month**,
  $164/year. That gap is the publishable number.
- **Composition, 16-day windows (Sept 1–16, 2024 vs Sept 1–16, 2026):**

  | | 2024 | 2026 |
  |---|---|---|
  | Total rides | 53,599,970 | 58,876,993 (+9.8%) |
  | MetroCard share | 38.19% | **0.451%** |
  | Unlimited passes (7- + 30-day) | 15.22% | ~0% |
  | 30-Day Unlimited | 3,979,572 rides (7.42%) | 31 rides |
  | 7-Day Unlimited | 4,178,161 rides (7.80%) | *category absent* |
  | OMNY Fair Fare | 262 | 2,425,633 (4.12%) |

  Both columns reconcile to their window totals. The 2026 reconciliation is verified
  against an independent `sum(ridership)` call; **the 2024 one is not** — see below.

## Key finding already established (needs your verification before publishing)

The monthly pass was 7.42% of subway ridership in September 2024 and is functionally
extinct today, while the only replacement product is weekly. The effective monthly
ceiling for a daily rider rose to $151.67 with no monthly product at any price.

Every figure in that sentence is in `constants.RECORDED_FARE_CLASS_RIDERSHIP` and is
re-checked by `pytest tests/`. A test failure means the MTA restated the data, which
is itself worth a line in the research log — do not loosen the assertion.

## What still needs to be done

1. **Run the station-level pull.** `farecap.stations.station_table(2024)` is written but
   has never executed. This is the load-bearing question and it is one query away:
   does 30-day-pass share vary by station, or is it flat? `dispersion_verdict()`
   decides it explicitly (IQR < 2pp ⇒ FLAT). **A FLAT verdict kills the geography and
   the equity framing, and that is a publishable finding — report it, don't go hunting
   for a subgroup that survives.** Highest-value work left.
2. **Reconcile the 2024 window total.** The fare-class split sums to 53,599,970 but no
   independent `count(*),sum(ridership)` call was ever made against `wujg-7c2s` for
   that window. `python src/collect.py windows --refresh` closes this. Until it runs,
   every 2024 share in this brief is unreconciled. The analogous check on 2026 is what
   caught a silent sixteen-day/two-day window error during scoping, so this is not
   ceremony.
3. **Source the retired 30-Day price.** Widely repeated as $132 and arithmetically
   consistent (132 ÷ 2.90 = 45.5 rides), but I could not find it in an MTA fare
   schedule or board document. `constants.METROCARD_30DAY_FINAL_PRICE_UNVERIFIED`
   holds it, unused. **Do not publish a before/after dollar figure until this is
   sourced from a primary document.** MTA board minutes or an archived fare schedule.
4. **Read the MTA data dictionary for both ridership datasets.** "Metrocard - Other"
   was 1.9M rides in 2024 and "OMNY - Other" is 2.3M now, and nobody has established
   what is in either bucket. If pass products are mixed into "Other," the 7.42% figure
   is a floor or is contaminated. This is the most likely way the headline number is
   wrong.
5. **Explain the student drop.** OMNY Students fell 2,343,858 → 1,570,400 across the two
   windows. That is large enough to be a category or school-calendar artifact rather
   than behavior, and it undercuts any claim about total composition until explained.
6. **Decide the ridership-vs-transfers denominator.** `ridership` and `transfers` are
   separate columns; shares change depending on which you use. Pick one, state it.
7. **Check the 2024/2026 dataset seam.** The windows come from two different datasets
   (`wujg-7c2s`, `5wq4-mkjj`) with a boundary at the start of 2025. Any schema or
   estimation-method change at that seam appears as a spurious trend. Look for an MTA
   note on methodology continuity.
8. **Decide whether Fair Fares earns a place.** `3tw8-6si8` is the only NYC Open Data
   source here and it is two columns, citywide monthly, no geography. Enrollment is
   flat-to-slightly-down since June 2026 (384,914 → 382,820 by August), eight months
   after the fare increase. Mildly interesting, analytically thin. Currently in scope
   only as an aside.
9. **Bus side, if the subway result holds.** `gxb3-akrn` and `kv7t-n8in` have the same
   shape and the fare cap covers local bus. Unverified columns. Only worth it if the
   subway geography is real.

## Constraints found the hard way during scoping

- An unbounded aggregate over `5wq4-mkjj` (45.2M rows) **times out**. Always bound
  `transit_timestamp` in `$where` before any `$group`. `farecap.collect` enforces this
  by construction — there is no code path that groups without a window.
- `transit_timestamp > '2026-09-01'` with no upper bound silently returned sixteen days
  and an implausible ~58M rides, which read as two days' data at first. The
  reconciliation step exists because of that error. Keep it.
- `max(transit_timestamp)` with `$order ... DESC $limit 1` returned 2026-09-02 while the
  same aggregate inside a bounded window returned 2026-09-16. Trust the bounded
  aggregate; the coverage end is 2026-09-16.
- Long query URLs get rejected outright by some HTTP intermediaries. Keep `$where`
  clauses terse.
- Socrata rate-limits unauthenticated requests with 429. `collect.soql` retries once
  then fails loudly rather than returning partial data. Set `SOCRATA_APP_TOKEN`.

## Style / sourcing standard to maintain

Every dataset ID, column name, and statistic in this project must be independently
re-verified by querying the live endpoint or reading the dataset's metadata — don't
trust anything in `data/` as still-current without a fresh check, since these portals
update continuously. Flag anything you cannot verify rather than dropping it silently.
SoQL text comparisons should be wrapped in `upper()` — text fields in these datasets
are inconsistently cased. Note the domain split: ridership is **state** open data
(`data.ny.gov`), Fair Fares is **city** (`data.cityofnewyork.us`).
