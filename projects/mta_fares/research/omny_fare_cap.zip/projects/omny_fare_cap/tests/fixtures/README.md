# Fixtures — the actual pulls from the 2026-09-28 session

These are verbatim Socrata responses recorded during the session that scoped
this project. They exist for two reasons: so the analysis code can be run and
tested without network access, and so there is a committed record of exactly
what the API said on that date (`data/raw/` is gitignored).

Seed them into the cache with:

    python src/seed_cache.py

Then `python src/analyze.py --composition --arithmetic` runs fully offline.

## What is here, and what is NOT

| Fixture | Query | Status |
|---|---|---|
| `fare_class_2024.json` | fare class x ridership, 2024-09-01..09-17, `wujg-7c2s` | verified |
| `fare_class_2026.json` | fare class x ridership, 2026-09-01..09-17, `5wq4-mkjj` | verified |
| `window_total_2026.json` | count/sum/min/max, 2026 window | verified |
| `fair_fares.json` | last 5 months of `3tw8-6si8` (not the full 92) | partial |

**Missing on purpose — do not fabricate these:**

- `window_total_2024.json` — the independent 2024 window total was never
  queried. The fare-class split sums to 53,599,970, but that figure has not
  been reconciled against a separate `sum(ridership)` call the way 2026 was.
  Run `python src/collect.py windows --refresh` first thing.
- `station_fare_class_2024.json` / `_2026.json` — the station-level pull, which
  is the load-bearing question, was never run. This is the first real analysis
  step, not a gap to paper over.
