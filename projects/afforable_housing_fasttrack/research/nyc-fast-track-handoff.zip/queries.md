# Reusable SoQL queries

All against Socrata endpoints on `data.cityofnewyork.us`. Unauthenticated queries are sometimes rate-limited (429) — wait and retry once. Always wrap text-field comparisons in `upper()`; casing is inconsistent across these datasets. Keep URLs under the proxy's length limit — split long `$where`/`$group` clauses across multiple simpler calls rather than one giant query if you hit a 403 "url exceeds maximum fetchable length."

## Dataset metadata / column check (do this first for any dataset before trusting field names)

```
https://data.cityofnewyork.us/api/views/{four-by-four}.json
```

## Affordable Housing Production by Building (hg8x-zxpr)

Row count and date range:
```
https://data.cityofnewyork.us/resource/hg8x-zxpr.json?$select=min(project_start_date) as first,max(project_start_date) as last,count(*) as n
```

New-construction affordable units by community district, HPD start date after a given cutoff (proxy for "in cycle"):
```
https://data.cityofnewyork.us/resource/hg8x-zxpr.json?$select=community_board,sum(all_counted_units) as u&$where=project_start_date>'2021-06-30' AND upper(reporting_construction_type) like 'NEW%25'&$group=community_board&$order=u&$limit=30
```

Construction-type split (sanity check that it's a clean binary):
```
https://data.cityofnewyork.us/resource/hg8x-zxpr.json?$select=upper(reporting_construction_type) as t,count(*) as n&$group=t
```

To tighten the numerator toward the rule's actual test, you'd ideally also require a DOB construction permit in-cycle. This dataset doesn't carry a DOB permit-issued date directly — check whether `bin`/`bbl` can be joined against a DOB permits dataset (e.g. DOB Permit Issuance, search the catalog) to add that condition.

## Housing Database by Community District (dbdt-5s7j)

Full denominator listing (all districts, including non-CD codes to filter out):
```
https://data.cityofnewyork.us/resource/dbdt-5s7j.json?$select=commntydst,cenunits20&$order=commntydst&$limit=80
```

To approximate the rule's denominator (Census + net new units through cycle start), add relevant `comp20XX` columns for years between 2020 and the cycle start:
```
https://data.cityofnewyork.us/resource/dbdt-5s7j.json?$select=commntydst,cenunits20,comp2020,comp2021&$order=commntydst&$limit=80
```
(Note: `comp2020`/`comp2021` are full calendar-year net completions, not split by half-year, so this will overshoot slightly if the cycle started mid-2021 — flag that imprecision if used.)

## Catalog search (for finding related/joinable datasets, e.g. DOB permits)

```
https://api.us.socrata.com/api/catalog/v1?domains=data.cityofnewyork.us&search_context=data.cityofnewyork.us&only=dataset&q={your+search+term}&limit=20
```

## General catalog housekeeping

Newly published datasets (useful for checking if DCP has posted a companion dataset for the fast-track list itself):
```
https://api.us.socrata.com/api/catalog/v1?domains=data.cityofnewyork.us&search_context=data.cityofnewyork.us&only=dataset&order=createdAt&limit=25
```

Recently updated (check periodically as Oct 1 approaches — DCP may publish the official list as a dataset rather than just a PDF/press release):
```
https://api.us.socrata.com/api/catalog/v1?domains=data.cityofnewyork.us&search_context=data.cityofnewyork.us&only=dataset&order=updatedAt&limit=40&q=fast%20track
```
