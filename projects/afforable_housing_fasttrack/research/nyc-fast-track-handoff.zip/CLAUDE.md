# NYC Affordable Housing Fast-Track: Rate vs. Count Investigation

Project brief for continuing this analysis. Read this file first, then `research-log.md` for sourced detail and `queries.md` for exact API calls. `data/` has raw pulls already fetched so you don't have to re-query everything from scratch (but see "what still needs verifying" below — re-check anything you're going to publish).

## The story

In November 2025, NYC voters approved a charter amendment (Question 2) that strips City Council approval out of the land-use process for affordable housing in the twelve community districts with the lowest **rate** of affordable housing development over the preceding five years. The City Planning Commission adopted the methodology by rule in April 2026. The first five-year measurement cycle closed June 30, 2026, and DCP must publish the list of twelve districts **no later than October 1, 2026** — about two weeks out as of this handoff.

The angle: reverse-engineer the list before DCP publishes it, using DCP's own published rule and public NYC Open Data, and show that the rate-based ranking produces meaningfully different results than the intuitive count-based ranking most coverage assumes — pulling in large, wealthy, high-stock Manhattan districts (Upper East Side, Upper West Side) that built more affordable units in absolute terms than most of the "obvious" low-production outer-borough districts, purely because the rule doesn't touch counts, it touches counts-over-stock.

## The rule, precisely

- **Cycle:** five years, July 1–June 30. First cycle just closed (6/30/2026). Repeats every five years.
- **Numerator:** "affordable dwelling units" (income-restricted units in an affordable housing building) that hit *both* an HPD-reported Start Date *and* a DOB construction permit, with at least one of those two milestones falling inside the cycle. Explicitly **excludes** affordable units in existing residential buildings under a preservation program receiving financial assistance — new production only.
- **Denominator:** total housing units = 2020 Decennial Census count + net new housing units through the cycle start. No distinction between affordable and market-rate — it's a raw housing-unit count.
- **Ranking:** straight citywide ranking of numerator/denominator, twelve lowest, all 59 community districts pooled (no borough quotas found in the rule text).
- **No exclusions found** in the rule for small/non-residential "districts" (joint interest areas), no tie-break procedure specified, no exemption for districts that recently rezoned.
- **Contested and settled:** commenters during rulemaking explicitly asked DCP to account for existing affordable housing stock in the denominator/formula. The Commission's adoption document states no changes were made in response. This is the crux of "why a rate that ignores existing stock" — see research-log.md for the exact quote and what's still unverified about the *rationale* (as opposed to the fact of rejection).

## Key finding already established (needs your verification before publishing)

Using new-construction affordable units with HPD start dates after 6/30/2021 as numerator, and 2020 Census housing units as denominator (a proxy — see caveats), a rate-based ranking swaps in Manhattan's Upper East Side (MN-08) and Upper West Side (MN-07) in place of Queens Community Board 8 (Fresh Meadows) and Queens Community Board 9 (Richmond Hill), compared to a simple count-based ranking of the bottom twelve. MN-08 and MN-07 each produced *more* affordable units in absolute terms (154 and 158) than every count-based-bottom-twelve district except QN-08 and QN-09 — but their housing stock (138,922 and 126,397 units respectively, the two largest of any community district) is roughly 2.5x the size of the districts they displace, so their rate is still worse.

This is the headline. See `research-log.md` for the full comparison table and every caveat attached to it.

## What still needs to be done

1. **Read the full CPC "Statement of Basis and Purpose"** (URL in research-log.md) end to end — the prior session only pulled fragments via an automated summarizer, not the full text. Look specifically for any stated rationale for rejecting a stock-adjusted metric (equity argument? simplicity? statutory constraint from the charter language itself?). This is the single most valuable thing to nail down — it upgrades "the rule structurally does X" into "the city says it means to do X."
2. **Find the charter amendment's actual text** (not secondary summaries) to check whether "rate" was specified by voters in the ballot language itself, or left to DCP's discretion in rulemaking — this determines whether the stock-blindness is a voter choice or an agency choice.
3. **Search Council Land Use Committee hearings / 2025 Charter Revision Commission testimony** for anyone — DCP, HPD, advocates, opponents — explicitly addressing why existing affordable stock isn't credited. Bay Ridge council member testimony (Kayla Santosuosso) might be a source given her district is expected to land on the list.
4. **Correct the denominator.** Currently using `cenunits20` alone (2020 Census count). The rule wants Census + net new units through cycle start (~mid-2021). The Housing Database by Community District dataset (`dbdt-5s7j`) has year-by-year net completions (`comp2010`...`comp2024`) — add 2020(partial)+2021(partial) net completions to `cenunits20` for a closer approximation. Unlikely to change the top of the list but could matter for the 11th/12th/13th/14th positions, which are separated by hundredths of a percentage point.
5. **Check for duplicate denominators.** SI-03 and BK-12 both show exactly 62,782 housing units; BX-10 and MN-11 both show exactly 54,738. Could be coincidence, could be a data artifact. Verify against Census ACS/decennial directly before trusting either.
6. **Tighten the numerator.** Currently using `project_start_date` alone as a proxy for the rule's actual dual condition (HPD start date AND DOB permit, either falling in-cycle). The `hg8x-zxpr` dataset's `reporting_construction_type` field splits cleanly into "New Construction" (4,674 rows) vs "Preservation" (4,576 rows) citywide, but this HPD label may not map exactly onto the rule's narrower exclusion (existing residential buildings under a preservation program with financial assistance specifically). Check DOB permit data if there's a way to join on `bbl`/`bin`.
7. **Filter denominator file to real community districts only.** `dbdt-5s7j` includes non-CD "joint interest areas" (Central Park = `164`, Rikers-adjacent codes, cemeteries, airports) with tiny or zero denominators that would falsely rank first if not excluded. Filter to the 59 real community district codes before ranking anything.
8. **Account for the missing quarter.** `hg8x-zxpr` (Affordable Housing Production by Building) was last updated 2026-05-19 and its data stops at `project_start_date` = 2026-03-31 — April–June 2026 (the last quarter of the cycle) is missing from the public file. Note this prominently; it could move borderline districts.
9. **Watch for DCP's actual list**, due by 10/1/2026 — compare against this reverse-engineered version once it posts, and write up any divergence (that's a story in itself if the two don't match).

## Style / sourcing standard to maintain

Every dataset ID, column name, and statistic in this project must be independently re-verified by querying the live endpoint or reading the dataset's metadata — don't trust anything in `data/` as still-current without a fresh check, since NYC Open Data updates continuously. Flag anything you cannot verify rather than dropping it silently. SoQL text comparisons should be wrapped in `upper()` — text fields in these datasets are inconsistently cased.
